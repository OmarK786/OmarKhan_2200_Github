
public class Exercise06_13 {
	public static void main(String[] args) {
		double sRange  = 1.0; 
		double eRange = 20.0;
		System.out.print("i	  m(i) 			" );
		System.out.println("\n- - - - - - - - - ");
		for (double i = sRange; i <= eRange; i ++) {
			System.out.printf("%-10.0f" , i);
			System.out.printf("%-7.4f\n" , Series(i));
		
		}
	}
public static double Series(double n ) {
	double sumOfSeries = 0;
	for (double i = 1; i <= n; i++) {
		sumOfSeries += i / (i + 1);
		
	}
	return sumOfSeries; 
}
}
